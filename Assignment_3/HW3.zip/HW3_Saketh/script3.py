multiply=1
for i in range(1,50):
    multiply=multiply*i
print(multiply)